package com.example.calculadorakotlin

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.widget.Button
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*

class MainActivity : AppCompatActivity() {
    var nuevoOperador= true
    var operador="+"
    var numeroViejo=""
    var esBinario=false
    var esDecimal=true
    var esHexadecimal= false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if(btnA!=null){
            btnA.isEnabled=false;
            btnB.isEnabled=false;
            btnC.isEnabled=false;
            btnD.isEnabled=false;
            btnE.isEnabled=false;
            btnF.isEnabled=false;
        }
    }

    fun numberEvent(view: View) {
        if (nuevoOperador){
            resultado.setText("")
            nuevoOperador=false
        }
        var btnclick = resultado.text.toString()
        var especialMasMenos= 0.0;
        var btnElegido = view as Button
        when(btnElegido.id){
            btn0.id -> {btnclick +="0"}
            btn1.id -> {btnclick +="1"}
            btn2.id -> {btnclick +="2"}
            btn3.id -> {btnclick +="3"}
            btn4.id -> {btnclick +="4"}
            btn5.id -> {btnclick +="5"}
            btn6.id -> {btnclick +="6"}
            btn7.id -> {btnclick +="7"}
            btn8.id -> {btnclick +="8"}
            btn9.id -> {btnclick +="9"}
            btnA.id -> {btnclick +="A"}
            btnB.id -> {btnclick +="B"}
            btnC.id -> {btnclick +="C"}
            btnD.id -> {btnclick +="D"}
            btnE.id -> {btnclick +="E"}
            btnF.id -> {btnclick +="F"}
            btnPunto.id -> {btnclick +="."}
            btnMasMenos.id ->{especialMasMenos = btnclick.toDouble() * (-1)
                btnclick=especialMasMenos.toString()}
        }
        resultado.setText(btnclick)
    }

    fun operadorEvent(view: View) {
        if(esDecimal==true){
            numeroViejo=resultado.text.toString()
        }else{
            if(esBinario){
                val num = resultado.text.toString().toInt();
                numeroViejo= binarioDecimal(num).toString()
            }else{
                if(esHexadecimal){
                    val num = resultado.text.toString();
                    numeroViejo= HexadecimalDecimal(num).toString()
                }
            }
        }

        nuevoOperador=true
        var btnElegido = view as Button
        when(btnElegido.id){
            btnRestar.id -> {operador="-"}
            btnSumar.id -> {operador="+"}
            btnMultiplicar.id -> {operador="*"}
            btnDividir.id -> {operador="/"}
            btnPorcentaje.id -> {operador="%"}
        }
    }

    fun igualEvent(view: View) {
        var numeroNuevo ="";
        if(esDecimal==true){
            numeroNuevo=resultado.text.toString()
        }else{
            if(esBinario==true){
                val num = resultado.text.toString().toInt();
                numeroNuevo= binarioDecimal(num).toString()
            }else{
                if(esHexadecimal){
                    val num = resultado.text.toString();
                    numeroNuevo= HexadecimalDecimal(num).toString()
                }
            }
        }
        var result= 0.0
        when (operador){
            "+" -> {result= numeroViejo.toDouble() + numeroNuevo.toDouble()}
            "-" -> {result= numeroViejo.toDouble() - numeroNuevo.toDouble()}
            "*" -> {result= numeroViejo.toDouble() * numeroNuevo.toDouble()}
            "/" -> {result= numeroViejo.toDouble() / numeroNuevo.toDouble()}
            "%" -> {result= (numeroViejo.toDouble()/100) *numeroNuevo.toDouble()}
        }



        if(esDecimal==true){
            Log.e("No esbinario","Sí, es binario")
            resultado.setText(result.toString())
        }else{
            if(esBinario==true){
                Log.e("Esbinario","Sí, es binario")
                resultado.setText( Integer.toBinaryString(result.toInt()).toString())
            }else{
                if(esHexadecimal){
                    resultado.setText(Integer.toHexString((result.toInt())).toString())
                }
            }
        }


    }

    fun borrarEvent(view: View) {
        resultado.setText(0.toString())
        nuevoOperador=true
    }

    fun binarioEvent(view: View) {
        btn2.isEnabled=false;
        btn3.isEnabled=false;
        btn4.isEnabled=false;
        btn5.isEnabled=false;
        btn6.isEnabled=false;
        btn7.isEnabled=false;
        btn8.isEnabled=false;
        btn9.isEnabled=false;
        btnA.isEnabled=false;
        btnB.isEnabled=false;
        btnC.isEnabled=false;
        btnD.isEnabled=false;
        btnE.isEnabled=false;
        btnF.isEnabled=false;
        btnPunto.isEnabled=false;


        esBinario=true
        esDecimal=false
        esHexadecimal= false
    }
    fun decimalEvent(view: View) {
        btnA.isEnabled=false;
        btnB.isEnabled=false;
        btnC.isEnabled=false;
        btnD.isEnabled=false;
        btnE.isEnabled=false;
        btnF.isEnabled=false;

        btn2.isEnabled=true;
        btn3.isEnabled=true;
        btn4.isEnabled=true;
        btn5.isEnabled=true;
        btn6.isEnabled=true;
        btn7.isEnabled=true;
        btn8.isEnabled=true;
        btn9.isEnabled=true;
        btnPunto.isEnabled=true;


        esBinario=false
        esDecimal=true
        esHexadecimal= false
    }
    fun hexadecimalEvent(view: View) {
        btn2.isEnabled=true;
        btn3.isEnabled=true;
        btn4.isEnabled=true;
        btn5.isEnabled=true;
        btn6.isEnabled=true;
        btn7.isEnabled=true;
        btn8.isEnabled=true;
        btn9.isEnabled=true;

        btnA.isEnabled=true;
        btnB.isEnabled=true;
        btnC.isEnabled=true;
        btnD.isEnabled=true;
        btnE.isEnabled=true;
        btnF.isEnabled=true;
        btnPunto.isEnabled=false;


        esBinario=false
        esDecimal=false
        esHexadecimal= true
    }

    fun binario(){
    }

    fun binarioDecimal(num: Int): Int {
            var num = num
            var decimalNumber = 0
            var i = 0
            var remainder: Int

            while (num != 0) {
                remainder = num % 10
                num /= 10
                decimalNumber += (remainder * Math.pow(2.0, i.toDouble())).toInt()
                ++i
            }
            return decimalNumber
        }

    fun  HexadecimalDecimal(hexadecimal: String): Int {
        var decimal: Int = 0
        var potencia = 0
        for (x in hexadecimal.length - 1 downTo 0) {
            val valor = caracterHexa(hexadecimal[x])
            val elevado = Math.pow(16.0, potencia.toDouble()).toInt() * valor
            decimal += elevado
            potencia++
        }
        return decimal
    }

    fun caracterHexa(caracter: Char): Int {
        return when (caracter) {
            'A' -> 10
            'B' -> 11
            'C' -> 12
            'D' -> 13
            'E' -> 14
            'F' -> 15
            'a' -> 10
            'b' -> 11
            'c' -> 12
            'd' -> 13
            'e' -> 14
            'f' -> 15
            else -> caracter.toString().toInt()
        }
    }

}